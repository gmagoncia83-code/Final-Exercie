# Wine Quality Prediction System

Based on the uploaded Section B laboratory exercise.

- Target: `quality >= 6` = GOOD QUALITY; `quality < 6` = NEEDS IMPROVEMENT.
- Original `quality` is excluded from predictor inputs to prevent target leakage.
- Main model: Random Forest.
- Comparison: Logistic Regression and Decision Tree using the same stratified 80/20 split.
- Evaluation: accuracy, precision, recall, F1, confusion matrix, 5-fold cross-validation, feature importance, and threshold comparison (0.50 vs 0.65).

## Run locally
```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```
The script downloads the UCI red-wine CSV on first run. The Streamlit app also trains automatically if the data/model files are absent.

## Dataset
https://archive.ics.uci.edu/dataset/186/wine+quality

## Generated outputs
`wine_model.pkl`, `wine_quality.csv`, `model_comparison.csv`, `cross_validation_results.csv`, `threshold_comparison.csv`, `confusion_matrix.png`, `feature_importance.png`, `feature_importance.csv`, `model_metadata.json`.

## Limitation
The model may not generalize to other wine types, producers, regions, or measurement conditions. It is only a preliminary screening aid, not a replacement for laboratory testing, sensory evaluation, food-safety procedures, or professional quality-control decisions.
