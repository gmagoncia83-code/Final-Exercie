# GitHub and Streamlit Community Cloud

1. Create a GitHub repository named `wine-quality-prediction`.
2. In this folder, run:
```bash
git init
git add train_model.py app.py requirements.txt README.md SAD_and_reflection.md DEPLOYMENT.md
git commit -m "Build wine quality prediction system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/wine-quality-prediction.git
git push -u origin main
```
3. Sign in at https://share.streamlit.io/, create a new app, select the repository, branch `main`, and entry point `app.py`.
4. Deploy. On first launch, the app downloads the UCI dataset and trains the model automatically; internet access is required.

Replace `YOUR-USERNAME` with your GitHub username. Never commit passwords or access tokens.
