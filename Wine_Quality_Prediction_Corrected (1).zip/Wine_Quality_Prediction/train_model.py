import json
from pathlib import Path
import warnings
import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, precision_score,
 recall_score, f1_score, ConfusionMatrixDisplay)
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

warnings.filterwarnings("ignore")
URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"

def pipeline(clf):
    return Pipeline([("imputer", SimpleImputer(strategy="median")),
                     ("scaler", StandardScaler()), ("classifier", clf)])

def main():
    if Path("wine_quality.csv").exists():
        df = pd.read_csv("wine_quality.csv")
    else:
        df = pd.read_csv(URL, sep=";")
        df.to_csv("wine_quality.csv", index=False)

    print("Shape:", df.shape)
    print("First five rows:\n", df.head())
    print("Data types:\n", df.dtypes)
    print("Missing values:\n", df.isnull().sum())
    print("Duplicates:", df.duplicated().sum())
    print("Quality distribution:\n", df.quality.value_counts().sort_index())

    df = df.drop_duplicates().copy()
    y = (df.quality >= 6).astype(int)
    X = df.drop(columns=["quality"])  # Prevent target leakage.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)

    models = {
      "Random Forest": pipeline(RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")),
      "Logistic Regression": pipeline(LogisticRegression(max_iter=2000, class_weight="balanced", random_state=42)),
      "Decision Tree": pipeline(DecisionTreeClassifier(class_weight="balanced", random_state=42))
    }
    comparison, fitted = [], {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        fitted[name] = model
        pred = model.predict(X_test)
        comparison.append({"Model": name, "Accuracy": accuracy_score(y_test, pred),
          "Good precision": precision_score(y_test, pred, zero_division=0),
          "Good recall": recall_score(y_test, pred, zero_division=0),
          "Good F1": f1_score(y_test, pred, zero_division=0)})
        print("\n", name, "\n", classification_report(y_test, pred, zero_division=0))
    pd.DataFrame(comparison).to_csv("model_comparison.csv", index=False)
    print(pd.DataFrame(comparison).to_string(index=False))

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_rows = []
    for name, model in models.items():
        scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="f1")
        cv_rows.append({"Model": name, "Mean CV F1": scores.mean(), "Std CV F1": scores.std()})
        print(f"{name} 5-fold CV F1: {scores.mean():.3f} +/- {scores.std():.3f}")
    pd.DataFrame(cv_rows).to_csv("cross_validation_results.csv", index=False)

    rf = fitted["Random Forest"]
    probs = rf.predict_proba(X_test)[:, 1]
    threshold_rows = []
    for threshold in [0.50, 0.65]:
        pred = (probs >= threshold).astype(int)
        threshold_rows.append({"Threshold": threshold,
          "Good precision": precision_score(y_test, pred, zero_division=0),
          "Good recall": recall_score(y_test, pred, zero_division=0),
          "Good F1": f1_score(y_test, pred, zero_division=0)})
    pd.DataFrame(threshold_rows).to_csv("threshold_comparison.csv", index=False)
    print("Threshold comparison:\n", pd.DataFrame(threshold_rows))

    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay.from_predictions(y_test, (probs >= .5).astype(int),
       display_labels=["Needs improvement", "Good quality"], cmap="Blues", ax=ax)
    fig.tight_layout()
    fig.savefig("confusion_matrix.png", dpi=160)
    plt.close(fig)

    importance = pd.Series(rf.named_steps["classifier"].feature_importances_, index=X.columns)
    importance.sort_values(ascending=False).to_csv("feature_importance.csv", header=["Importance"])
    ax = importance.sort_values().plot(kind="barh", figsize=(8, 6))
    ax.set_title("Random Forest Feature Importance")
    plt.tight_layout()
    plt.savefig("feature_importance.png", dpi=160)
    plt.close()

    joblib.dump(rf, "wine_model.pkl")
    Path("model_metadata.json").write_text(json.dumps({
      "target": "quality >= 6 = GOOD QUALITY; quality < 6 = NEEDS IMPROVEMENT",
      "features": list(X.columns), "model": "Random Forest",
      "test_size": .20, "random_state": 42
    }, indent=2), encoding="utf-8")
    print("Saved model and evaluation artifacts.")

if __name__ == "__main__":
    main()
