from pathlib import Path
import subprocess, sys
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Wine Quality Prediction", page_icon="🍷", layout="wide")
if not Path("wine_model.pkl").exists() or not Path("wine_quality.csv").exists():
    with st.spinner("Preparing dataset and model..."):
        run = subprocess.run([sys.executable, "train_model.py"], capture_output=True, text=True)
    if run.returncode:
        st.error("Model preparation failed.")
        st.code(run.stderr or run.stdout)
        st.stop()

@st.cache_resource
def get_model():
    return joblib.load("wine_model.pkl")
@st.cache_data
def get_data():
    return pd.read_csv("wine_quality.csv")

model, data = get_model(), get_data()
features = list(model.feature_names_in_)
st.title("🍷 Wine Quality Prediction System")
st.caption("Classroom prototype for preliminary red-wine quality screening.")
c1, c2, c3 = st.columns(3)
c1.metric("Dataset records", len(data))
c2.metric("Average quality score", round(data.quality.mean(), 2))
c3.metric("Good-quality records", int((data.quality >= 6).sum()))
st.subheader("Dataset preview")
st.dataframe(data.head(10), use_container_width=True)
st.subheader("Predict uploaded wine samples")
st.write("Upload a CSV with all 11 measurement columns. Do not include the original quality column.")
st.download_button("Download sample input CSV", data.drop(columns=["quality"]).head(5).to_csv(index=False),
                   "sample_wine_input.csv", "text/csv")
threshold = st.slider("GOOD QUALITY probability threshold", .10, .90, .50, .05)
uploaded = st.file_uploader("Choose CSV", type=["csv"])
if uploaded:
    try:
        samples = pd.read_csv(uploaded)
        missing = [c for c in features if c not in samples.columns]
        if missing:
            st.error("Missing required columns: " + ", ".join(missing))
        else:
            probability = model.predict_proba(samples[features])[:, 1]
            labels = (probability >= threshold).astype(int)
            result = samples.copy()
            result["Good quality probability"] = probability.round(4)
            result["Prediction"] = ["GOOD QUALITY" if x else "NEEDS IMPROVEMENT" for x in labels]
            st.dataframe(result, use_container_width=True)
            st.metric("Predicted GOOD QUALITY samples", int(labels.sum()))
            st.download_button("Download prediction results", result.to_csv(index=False),
                               "wine_quality_predictions.csv", "text/csv")
    except Exception as e:
        st.error(f"Could not process file: {e}")
st.info("Predictions are preliminary screening results only, not a substitute for laboratory testing, sensory evaluation, food-safety procedures, or professional quality-control decisions.")
